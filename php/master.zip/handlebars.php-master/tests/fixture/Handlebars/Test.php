<?php

namespace Handlebars;
/**
 * Class Handlebars_Class
 */

class Test
{

}
