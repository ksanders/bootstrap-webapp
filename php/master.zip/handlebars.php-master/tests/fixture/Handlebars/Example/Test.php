<?php

namespace Handlebars\Example;
/**
 * Class Handlebars_Example_Class
 */
class Test
{

}